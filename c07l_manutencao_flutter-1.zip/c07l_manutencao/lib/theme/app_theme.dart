import 'package:flutter/material.dart';
import '../models/equipamento.dart';

/// Cores e temas centralizados do app.
/// Interface otimizada para uso em campo: alto contraste, botões grandes.
class AppTheme {
  AppTheme._();

  // Cor principal da marca / equipe C07-L.
  static const Color corPrimaria = Color(0xFF0D47A1); // azul forte
  static const Color corSecundaria = Color(0xFF00897B); // verde-azulado

  // Cores de status de manutenção (usadas em badges, cards e dashboard).
  static const Color statusVerde = Color(0xFF2E7D32);
  static const Color statusAmarelo = Color(0xFFF9A825);
  static const Color statusLaranja = Color(0xFFEF6C00);
  static const Color statusVermelho = Color(0xFFC62828);

  static Color corDoStatus(StatusManutencao status) {
    switch (status) {
      case StatusManutencao.verde:
        return statusVerde;
      case StatusManutencao.amarelo:
        return statusAmarelo;
      case StatusManutencao.laranja:
        return statusLaranja;
      case StatusManutencao.vermelho:
        return statusVermelho;
    }
  }

  static IconData iconeDaCategoria(CategoriaEquipamento categoria) {
    switch (categoria) {
      case CategoriaEquipamento.gerador:
        return Icons.bolt;
      case CategoriaEquipamento.caminhonete:
        return Icons.directions_car;
      case CategoriaEquipamento.caminhaoMuc:
        return Icons.local_shipping;
      case CategoriaEquipamento.drone:
        return Icons.airplanemode_active;
    }
  }

  // Tamanho mínimo recomendado para toque em campo (luvas, sol forte, etc.)
  static const double alturaBotaoGrande = 56;
  static const double tamanhoIconeGrande = 28;

  static ThemeData get temaClaro {
    final base = ThemeData(
      brightness: Brightness.light,
      useMaterial3: true,
      colorSchemeSeed: corPrimaria,
      scaffoldBackgroundColor: const Color(0xFFF5F7FA),
    );
    return base.copyWith(
      appBarTheme: base.appBarTheme.copyWith(
        centerTitle: false,
        elevation: 0,
        backgroundColor: corPrimaria,
        foregroundColor: Colors.white,
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          minimumSize: const Size.fromHeight(alturaBotaoGrande),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: corSecundaria,
        foregroundColor: Colors.white,
      ),
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }

  static ThemeData get temaEscuro {
    final base = ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      colorSchemeSeed: corPrimaria,
    );
    return base.copyWith(
      appBarTheme: base.appBarTheme.copyWith(
        centerTitle: false,
        elevation: 0,
        titleTextStyle: const TextStyle(
          color: Colors.white,
          fontSize: 20,
          fontWeight: FontWeight.w600,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          minimumSize: const Size.fromHeight(alturaBotaoGrande),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: corSecundaria,
        foregroundColor: Colors.white,
      ),
      cardTheme: CardThemeData(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
    );
  }
}
