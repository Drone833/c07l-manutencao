import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';

import '../providers/equipamento_provider.dart';
import 'equipamento_detail_screen.dart';

/// Tela de escaneamento de QR Code. Ao ler um código gerado pelo próprio
/// app (prefixo "C07L-EQUIP:"), abre diretamente o cadastro do equipamento.
class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key});

  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  final MobileScannerController _controller = MobileScannerController();
  bool _processando = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _aoDetectar(BarcodeCapture captura) async {
    if (_processando) return;
    final codigo = captura.barcodes.firstOrNull?.rawValue;
    if (codigo == null) return;

    if (!codigo.startsWith(prefixoQrCode)) {
      _mostrarErro('Este QR Code não pertence a um equipamento cadastrado no app.');
      return;
    }

    final idTexto = codigo.substring(prefixoQrCode.length);
    final id = int.tryParse(idTexto);
    if (id == null) {
      _mostrarErro('QR Code inválido.');
      return;
    }

    setState(() => _processando = true);

    final equipamento = await context.read<EquipamentoProvider>().buscarPorId(id);
    if (!mounted) return;

    if (equipamento == null) {
      _mostrarErro('Equipamento não encontrado (pode ter sido excluído).');
      setState(() => _processando = false);
      return;
    }

    await Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => EquipamentoDetailScreen(equipamentoId: id)),
    );
  }

  void _mostrarErro(String mensagem) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mensagem)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Escanear QR Code'),
        actions: [
          IconButton(
            icon: const Icon(Icons.flash_on),
            onPressed: () => _controller.toggleTorch(),
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(controller: _controller, onDetect: _aoDetectar),
          // Moldura de mira central, para facilitar o enquadramento em campo.
          Center(
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white, width: 3),
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          if (_processando)
            const Positioned.fill(
              child: ColoredBox(
                color: Colors.black45,
                child: Center(child: CircularProgressIndicator()),
              ),
            ),
          Positioned(
            bottom: 24,
            left: 24,
            right: 24,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Aponte a câmera para o QR Code colado no equipamento',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

extension _FirstOrNull<T> on List<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
