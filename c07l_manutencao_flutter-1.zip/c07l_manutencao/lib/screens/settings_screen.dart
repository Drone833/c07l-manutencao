import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/equipamento_provider.dart';
import '../services/export_import_service.dart';
import '../services/pdf_service.dart';
import '../theme/app_theme.dart';

/// Tela de configurações: tema claro/escuro, exportação/importação de
/// dados (backup) e geração do relatório PDF geral da frota.
///
/// A sincronização em nuvem é opcional e não está habilitada por padrão
/// (o app funciona 100% offline). O botão de exportar já gera o arquivo
/// no formato usado para uma futura integração com um servidor próprio.
class SettingsScreen extends StatefulWidget {
  final ValueChanged<ThemeMode> onAlterarTema;
  final ThemeMode temaAtual;

  const SettingsScreen({super.key, required this.onAlterarTema, required this.temaAtual});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _processando = false;

  Future<void> _gerarRelatorioGeral() async {
    setState(() => _processando = true);
    final provider = context.read<EquipamentoProvider>();
    await provider.carregarEquipamentos();
    final arquivo = await PdfService.gerarRelatorioGeral(provider.equipamentos);
    await PdfService.compartilharPdf(arquivo);
    setState(() => _processando = false);
  }

  Future<void> _exportarDados() async {
    setState(() => _processando = true);
    await ExportImportService.exportarECompartilhar();
    setState(() => _processando = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Backup exportado com sucesso.')),
      );
    }
  }

  Future<void> _importarDados() async {
    final substituir = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Importar dados'),
        content: const Text(
          'Deseja substituir todos os dados atuais pelo backup selecionado, '
          'ou apenas adicionar os equipamentos do arquivo aos já existentes?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Adicionar'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.statusVermelho),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Substituir tudo'),
          ),
        ],
      ),
    );
    if (substituir == null) return; // usuário cancelou o diálogo

    setState(() => _processando = true);
    final quantidade = await ExportImportService.importarDados(substituirTudo: substituir);
    if (mounted) {
      await context.read<EquipamentoProvider>().carregarEquipamentos();
      setState(() => _processando = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$quantidade registros importados.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: AbsorbPointer(
        absorbing: _processando,
        child: Opacity(
          opacity: _processando ? 0.5 : 1,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _secao('Aparência'),
              Card(
                child: Column(
                  children: [
                    RadioListTile<ThemeMode>(
                      title: const Text('Claro'),
                      value: ThemeMode.light,
                      groupValue: widget.temaAtual,
                      onChanged: (v) => widget.onAlterarTema(v!),
                    ),
                    RadioListTile<ThemeMode>(
                      title: const Text('Escuro'),
                      value: ThemeMode.dark,
                      groupValue: widget.temaAtual,
                      onChanged: (v) => widget.onAlterarTema(v!),
                    ),
                    RadioListTile<ThemeMode>(
                      title: const Text('Padrão do sistema'),
                      value: ThemeMode.system,
                      groupValue: widget.temaAtual,
                      onChanged: (v) => widget.onAlterarTema(v!),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              _secao('Relatórios'),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.picture_as_pdf),
                  title: const Text('Gerar relatório geral em PDF'),
                  subtitle: const Text('Situação de todos os equipamentos cadastrados'),
                  onTap: _gerarRelatorioGeral,
                ),
              ),
              const SizedBox(height: 20),

              _secao('Backup de dados'),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.upload_file),
                      title: const Text('Exportar dados'),
                      subtitle: const Text('Gera um backup em .json de equipamentos e histórico'),
                      onTap: _exportarDados,
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.download),
                      title: const Text('Importar dados'),
                      subtitle: const Text('Restaura um backup .json exportado anteriormente'),
                      onTap: _importarDados,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              _secao('Sincronização na nuvem (opcional)'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    'O aplicativo funciona totalmente offline. O arquivo de backup '
                    'gerado em "Exportar dados" já está no formato pronto para uma '
                    'futura sincronização automática com um servidor da equipe — '
                    'basta conectar um endpoint próprio quando desejar.',
                    style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _secao(String titulo) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, left: 4),
      child: Text(
        titulo,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
      ),
    );
  }
}
