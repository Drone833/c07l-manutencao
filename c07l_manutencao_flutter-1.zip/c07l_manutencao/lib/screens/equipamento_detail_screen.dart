import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models/equipamento.dart';
import '../models/manutencao.dart';
import '../providers/equipamento_provider.dart';
import '../services/pdf_service.dart';
import '../theme/app_theme.dart';
import '../widgets/status_badge.dart';
import 'equipamento_form_screen.dart';
import 'manutencao_form_screen.dart';

/// Prefixo usado para identificar QR Codes gerados por este app,
/// evitando abrir o cadastro errado ao escanear um QR Code de terceiros.
const String prefixoQrCode = 'C07L-EQUIP:';

/// Tela de detalhes de um equipamento: dados gerais, QR Code, ações
/// rápidas (atualizar valor / registrar manutenção) e histórico.
class EquipamentoDetailScreen extends StatefulWidget {
  final int equipamentoId;

  const EquipamentoDetailScreen({super.key, required this.equipamentoId});

  @override
  State<EquipamentoDetailScreen> createState() => _EquipamentoDetailScreenState();
}

class _EquipamentoDetailScreenState extends State<EquipamentoDetailScreen> {
  Equipamento? _equipamento;
  List<Manutencao> _historico = [];
  bool _carregando = true;
  final _formatoData = DateFormat('dd/MM/yyyy');

  @override
  void initState() {
    super.initState();
    _carregar();
  }

  Future<void> _carregar() async {
    setState(() => _carregando = true);
    final provider = context.read<EquipamentoProvider>();
    final equipamento = await provider.buscarPorId(widget.equipamentoId);
    final historico = await provider.historicoDoEquipamento(widget.equipamentoId);
    setState(() {
      _equipamento = equipamento;
      _historico = historico;
      _carregando = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final eq = _equipamento;
    if (eq == null) {
      return const Scaffold(body: Center(child: Text('Equipamento não encontrado')));
    }

    final unidade = eq.categoria.unidade;

    return Scaffold(
      appBar: AppBar(
        title: Text(eq.nome, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            tooltip: 'Editar',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => EquipamentoFormScreen(equipamento: eq)),
              );
              _carregar();
            },
          ),
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            tooltip: 'Gerar PDF',
            onPressed: () async {
              final arquivo = await PdfService.gerarRelatorioEquipamento(eq, _historico);
              await PdfService.compartilharPdf(arquivo);
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Excluir',
            onPressed: () => _confirmarExclusao(context, eq),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _carregar,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildCabecalho(eq, unidade),
            const SizedBox(height: 20),
            _buildAcoesRapidas(eq),
            const SizedBox(height: 20),
            _buildQrCode(eq),
            const SizedBox(height: 24),
            _buildHistorico(unidade),
          ],
        ),
      ),
    );
  }

  Widget _buildCabecalho(Equipamento eq, String unidade) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (eq.fotoPath != null && File(eq.fotoPath!).existsSync())
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(File(eq.fotoPath!), width: 72, height: 72, fit: BoxFit.cover),
                  )
                else
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      color: AppTheme.corPrimaria.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(AppTheme.iconeDaCategoria(eq.categoria), size: 34, color: AppTheme.corPrimaria),
                  ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(eq.nome, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Text('${eq.categoria.label} • Pat. ${eq.patrimonio}',
                          style: TextStyle(color: Colors.grey.shade600)),
                      const SizedBox(height: 6),
                      StatusBadge(status: eq.status),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 28),
            _linhaInfo('${eq.categoria.rotuloControle} atual', '${eq.valorAtual.toStringAsFixed(1)} $unidade'),
            _linhaInfo('Próxima manutenção em', '${eq.proximaManutencao.toStringAsFixed(1)} $unidade'),
            _linhaInfo(
              eq.restante >= 0 ? 'Faltam' : 'Vencida há',
              '${eq.restante.abs().toStringAsFixed(1)} $unidade',
              destaque: AppTheme.corDoStatus(eq.status),
            ),
            _linhaInfo('Última atualização', _formatoData.format(eq.ultimaAtualizacao)),
            if (eq.observacoes.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Observações:', style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w600)),
              Text(eq.observacoes),
            ],
          ],
        ),
      ),
    );
  }

  Widget _linhaInfo(String label, String valor, {Color? destaque}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Colors.grey.shade700)),
          Text(
            valor,
            style: TextStyle(fontWeight: FontWeight.bold, color: destaque),
          ),
        ],
      ),
    );
  }

  Widget _buildAcoesRapidas(Equipamento eq) {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () => _dialogoAtualizarValor(eq),
            icon: const Icon(Icons.speed),
            label: const Text('Atualizar valor'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.corSecundaria),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => ManutencaoFormScreen(equipamento: eq)),
              );
              _carregar();
            },
            icon: const Icon(Icons.build),
            label: const Text('Registrar manutenção'),
          ),
        ),
      ],
    );
  }

  Widget _buildQrCode(Equipamento eq) {
    final conteudoQr = '$prefixoQrCode${eq.id}';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('QR Code do equipamento', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 4),
            Text(
              'Cole no equipamento para identificação rápida em campo.',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12.5),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 14),
            QrImageView(
              data: conteudoQr,
              size: 180,
              backgroundColor: Colors.white,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHistorico(String unidade) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Histórico de manutenções',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (_historico.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20),
            child: Center(
              child: Text('Nenhuma manutenção registrada ainda.',
                  style: TextStyle(color: Colors.grey.shade600)),
            ),
          )
        else
          ..._historico.map((m) => Card(
                child: ListTile(
                  leading: const Icon(Icons.build_circle_outlined),
                  title: Text('${_formatoData.format(m.data)} — ${m.valorNoMomento.toStringAsFixed(1)} $unidade'),
                  subtitle: Text(
                    [
                      if (m.pecasTrocadas.isNotEmpty) 'Peças: ${m.pecasTrocadas}',
                      if (m.custo > 0) 'Custo: R\$ ${m.custo.toStringAsFixed(2)}',
                      if (m.observacoes.isNotEmpty) m.observacoes,
                    ].join('\n'),
                  ),
                  isThreeLine: true,
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, size: 20),
                    onPressed: () async {
                      await context.read<EquipamentoProvider>().excluirManutencao(m.id!);
                      _carregar();
                    },
                  ),
                ),
              )),
      ],
    );
  }

  Future<void> _dialogoAtualizarValor(Equipamento eq) async {
    final controller = TextEditingController(text: eq.valorAtual.toString());
    final unidade = eq.categoria.unidade;

    final novoValor = await showDialog<double>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Atualizar ${eq.categoria.rotuloControle.toLowerCase()}'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(labelText: 'Novo valor ($unidade)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          ElevatedButton(
            onPressed: () {
              final valor = double.tryParse(controller.text.replaceAll(',', '.'));
              Navigator.pop(context, valor);
            },
            child: const Text('Salvar'),
          ),
        ],
      ),
    );

    if (novoValor != null) {
      await context.read<EquipamentoProvider>().atualizarValorAtual(eq, novoValor);
      _carregar();
    }
  }

  Future<void> _confirmarExclusao(BuildContext context, Equipamento eq) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir equipamento?'),
        content: Text('Isso removerá "${eq.nome}" e todo o seu histórico de manutenções. Esta ação não pode ser desfeita.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.statusVermelho),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (confirmar == true && context.mounted) {
      await context.read<EquipamentoProvider>().excluirEquipamento(eq.id!);
      if (context.mounted) Navigator.pop(context);
    }
  }
}
