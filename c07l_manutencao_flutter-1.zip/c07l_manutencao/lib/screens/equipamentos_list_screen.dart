import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/equipamento.dart';
import '../providers/equipamento_provider.dart';
import '../widgets/equipamento_card.dart';
import 'equipamento_detail_screen.dart';
import 'equipamento_form_screen.dart';

/// Lista completa de equipamentos, com busca por nome/patrimônio e
/// filtros por categoria e por situação (status).
class EquipamentosListScreen extends StatefulWidget {
  final StatusManutencao? filtroStatusInicial;
  final CategoriaEquipamento? filtroCategoriaInicial;

  const EquipamentosListScreen({
    super.key,
    this.filtroStatusInicial,
    this.filtroCategoriaInicial,
  });

  @override
  State<EquipamentosListScreen> createState() => _EquipamentosListScreenState();
}

class _EquipamentosListScreenState extends State<EquipamentosListScreen> {
  final _buscaController = TextEditingController();
  CategoriaEquipamento? _categoriaFiltro;
  StatusManutencao? _statusFiltro;

  @override
  void initState() {
    super.initState();
    _categoriaFiltro = widget.filtroCategoriaInicial;
    _statusFiltro = widget.filtroStatusInicial;
    WidgetsBinding.instance.addPostFrameCallback((_) => _recarregar());
  }

  @override
  void dispose() {
    _buscaController.dispose();
    super.dispose();
  }

  Future<void> _recarregar() async {
    await context.read<EquipamentoProvider>().carregarEquipamentos(
          termoBusca: _buscaController.text,
          categoria: _categoriaFiltro,
        );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EquipamentoProvider>();

    // Filtro de status é aplicado localmente (categoria/busca já vêm do banco).
    final lista = _statusFiltro == null
        ? provider.equipamentos
        : provider.equipamentos.where((e) => e.status == _statusFiltro).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Equipamentos')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: TextField(
              controller: _buscaController,
              decoration: InputDecoration(
                hintText: 'Buscar por nome ou patrimônio...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _buscaController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _buscaController.clear();
                          _recarregar();
                        },
                      )
                    : null,
              ),
              onChanged: (_) => _recarregar(),
            ),
          ),
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _chipCategoria(null, 'Todas'),
                for (final cat in CategoriaEquipamento.values)
                  _chipCategoria(cat, cat.label),
              ],
            ),
          ),
          const SizedBox(height: 4),
          if (_statusFiltro != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerLeft,
                child: InputChip(
                  label: Text('Filtro: ${_statusFiltro!.label}'),
                  onDeleted: () => setState(() => _statusFiltro = null),
                ),
              ),
            ),
          Expanded(
            child: provider.carregando
                ? const Center(child: CircularProgressIndicator())
                : lista.isEmpty
                    ? _estadoVazio()
                    : RefreshIndicator(
                        onRefresh: _recarregar,
                        child: ListView.builder(
                          padding: const EdgeInsets.only(top: 8, bottom: 88),
                          itemCount: lista.length,
                          itemBuilder: (context, index) {
                            final equipamento = lista[index];
                            return EquipamentoCard(
                              equipamento: equipamento,
                              onTap: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => EquipamentoDetailScreen(
                                      equipamentoId: equipamento.id!,
                                    ),
                                  ),
                                );
                                _recarregar();
                              },
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Novo'),
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const EquipamentoFormScreen()),
          );
          _recarregar();
        },
      ),
    );
  }

  Widget _chipCategoria(CategoriaEquipamento? categoria, String label) {
    final selecionado = _categoriaFiltro == categoria;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selecionado,
        onSelected: (_) {
          setState(() => _categoriaFiltro = categoria);
          _recarregar();
        },
      ),
    );
  }

  Widget _estadoVazio() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inbox, size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(
              'Nenhum equipamento encontrado',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 15),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
