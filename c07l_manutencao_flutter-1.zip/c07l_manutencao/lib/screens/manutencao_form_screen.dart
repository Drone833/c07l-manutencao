import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models/equipamento.dart';
import '../models/manutencao.dart';
import '../providers/equipamento_provider.dart';

/// Formulário para registrar uma manutenção concluída: valor no momento,
/// peças trocadas, custo, observações e fotos.
class ManutencaoFormScreen extends StatefulWidget {
  final Equipamento equipamento;

  const ManutencaoFormScreen({super.key, required this.equipamento});

  @override
  State<ManutencaoFormScreen> createState() => _ManutencaoFormScreenState();
}

class _ManutencaoFormScreenState extends State<ManutencaoFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _valorController = TextEditingController();
  final _pecasController = TextEditingController();
  final _custoController = TextEditingController(text: '0');
  final _observacoesController = TextEditingController();
  DateTime _data = DateTime.now();
  final List<String> _fotos = [];
  bool _salvando = false;

  @override
  void initState() {
    super.initState();
    _valorController.text = widget.equipamento.valorAtual.toString();
  }

  Future<void> _adicionarFoto() async {
    final picker = ImagePicker();
    final imagem = await picker.pickImage(source: ImageSource.camera, imageQuality: 75, maxWidth: 1280);
    if (imagem == null) return;

    final dir = await getApplicationDocumentsDirectory();
    final nomeArquivo = 'manut_${DateTime.now().millisecondsSinceEpoch}${p.extension(imagem.path)}';
    final destino = File('${dir.path}/$nomeArquivo');
    await destino.writeAsBytes(await imagem.readAsBytes());

    setState(() => _fotos.add(destino.path));
  }

  Future<void> _selecionarData() async {
    final selecionada = await showDatePicker(
      context: context,
      initialDate: _data,
      firstDate: DateTime(2015),
      lastDate: DateTime.now().add(const Duration(days: 1)),
    );
    if (selecionada != null) setState(() => _data = selecionada);
  }

  Future<void> _salvar() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _salvando = true);

    final manutencao = Manutencao(
      equipamentoId: widget.equipamento.id!,
      data: _data,
      valorNoMomento: double.parse(_valorController.text.replaceAll(',', '.')),
      pecasTrocadas: _pecasController.text.trim(),
      custo: double.tryParse(_custoController.text.replaceAll(',', '.')) ?? 0,
      observacoes: _observacoesController.text.trim(),
      fotos: _fotos,
    );

    await context.read<EquipamentoProvider>().registrarManutencaoConcluida(
          widget.equipamento,
          manutencao,
        );

    if (mounted) {
      setState(() => _salvando = false);
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _valorController.dispose();
    _pecasController.dispose();
    _custoController.dispose();
    _observacoesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final unidade = widget.equipamento.categoria.unidade;

    return Scaffold(
      appBar: AppBar(title: const Text('Registrar manutenção')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Data da manutenção'),
              subtitle: Text('${_data.day.toString().padLeft(2, '0')}/'
                  '${_data.month.toString().padLeft(2, '0')}/${_data.year}'),
              trailing: const Icon(Icons.calendar_today),
              onTap: _selecionarData,
            ),
            const Divider(),
            TextFormField(
              controller: _valorController,
              decoration: InputDecoration(
                labelText: '${widget.equipamento.categoria.rotuloControle} no momento ($unidade)',
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (v) => (v == null || double.tryParse(v.replaceAll(',', '.')) == null)
                  ? 'Informe um valor válido'
                  : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _pecasController,
              decoration: const InputDecoration(labelText: 'Peças trocadas'),
              maxLines: 2,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _custoController,
              decoration: const InputDecoration(labelText: 'Custo (R\$)'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _observacoesController,
              decoration: const InputDecoration(labelText: 'Observações'),
              maxLines: 3,
            ),
            const SizedBox(height: 18),
            Text('Fotos', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final caminho in _fotos)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(File(caminho), width: 72, height: 72, fit: BoxFit.cover),
                  ),
                InkWell(
                  onTap: _adicionarFoto,
                  child: Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade400),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.add_a_photo),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 28),
            ElevatedButton.icon(
              onPressed: _salvando ? null : _salvar,
              icon: _salvando
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.check),
              label: const Text('Concluir e registrar manutenção'),
            ),
          ],
        ),
      ),
    );
  }
}
