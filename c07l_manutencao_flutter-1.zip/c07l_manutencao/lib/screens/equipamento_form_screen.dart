import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models/equipamento.dart';
import '../providers/equipamento_provider.dart';
import '../theme/app_theme.dart';

/// Tela de cadastro (equipamento == null) ou edição (equipamento != null).
class EquipamentoFormScreen extends StatefulWidget {
  final Equipamento? equipamento;

  const EquipamentoFormScreen({super.key, this.equipamento});

  @override
  State<EquipamentoFormScreen> createState() => _EquipamentoFormScreenState();
}

class _EquipamentoFormScreenState extends State<EquipamentoFormScreen> {
  final _formKey = GlobalKey<FormState>();

  late CategoriaEquipamento _categoria;
  final _nomeController = TextEditingController();
  final _patrimonioController = TextEditingController();
  final _valorAtualController = TextEditingController();
  final _intervaloController = TextEditingController();
  final _observacoesController = TextEditingController();
  final List<TextEditingController> _alertasControllers = [];

  String? _fotoPath;
  bool _salvando = false;

  bool get _editando => widget.equipamento != null;

  @override
  void initState() {
    super.initState();
    final eq = widget.equipamento;
    _categoria = eq?.categoria ?? CategoriaEquipamento.gerador;
    _nomeController.text = eq?.nome ?? '';
    _patrimonioController.text = eq?.patrimonio ?? '';
    _valorAtualController.text = eq?.valorAtual.toString() ?? '';
    _intervaloController.text =
        (eq?.intervaloManutencao ?? _categoria.intervaloPadrao).toString();
    _observacoesController.text = eq?.observacoes ?? '';
    _fotoPath = eq?.fotoPath;
    _configurarAlertasControllers(eq?.alertasConfigurados ?? _categoria.alertasPadrao);
  }

  void _configurarAlertasControllers(List<double> valores) {
    _alertasControllers.clear();
    for (final v in valores) {
      _alertasControllers.add(TextEditingController(text: v.toString()));
    }
  }

  void _aoTrocarCategoria(CategoriaEquipamento? nova) {
    if (nova == null) return;
    setState(() {
      _categoria = nova;
      if (!_editando) {
        // Só sugere novos padrões automaticamente em um cadastro novo.
        _intervaloController.text = nova.intervaloPadrao.toString();
        _configurarAlertasControllers(nova.alertasPadrao);
      }
    });
  }

  Future<void> _escolherFoto() async {
    final picker = ImagePicker();
    final imagem = await picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 75,
      maxWidth: 1280,
    );
    if (imagem == null) return;

    // Copia a imagem para o diretório de documentos do app, garantindo
    // que ela continue disponível mesmo se o arquivo original for apagado.
    final dir = await getApplicationDocumentsDirectory();
    final nomeArquivo = 'foto_${DateTime.now().millisecondsSinceEpoch}${p.extension(imagem.path)}';
    final destino = File('${dir.path}/$nomeArquivo');
    await destino.writeAsBytes(await imagem.readAsBytes());

    setState(() => _fotoPath = destino.path);
  }

  Future<void> _salvar() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _salvando = true);

    final valorAtual = double.parse(_valorAtualController.text.replaceAll(',', '.'));
    final intervalo = double.parse(_intervaloController.text.replaceAll(',', '.'));
    final alertas = _alertasControllers
        .map((c) => double.parse(c.text.replaceAll(',', '.')))
        .toList();

    final proximaManutencao = _editando
        ? widget.equipamento!.proximaManutencao
        : valorAtual + intervalo;

    final equipamento = Equipamento(
      id: widget.equipamento?.id,
      nome: _nomeController.text.trim(),
      categoria: _categoria,
      patrimonio: _patrimonioController.text.trim(),
      valorAtual: valorAtual,
      proximaManutencao: proximaManutencao,
      intervaloManutencao: intervalo,
      ultimaAtualizacao: DateTime.now(),
      fotoPath: _fotoPath,
      observacoes: _observacoesController.text.trim(),
      alertasConfigurados: alertas,
      ultimoNivelAlertaNotificado: widget.equipamento?.ultimoNivelAlertaNotificado ?? -1,
    );

    await context.read<EquipamentoProvider>().salvarEquipamento(equipamento);

    if (mounted) {
      setState(() => _salvando = false);
      Navigator.pop(context);
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _patrimonioController.dispose();
    _valorAtualController.dispose();
    _intervaloController.dispose();
    _observacoesController.dispose();
    for (final c in _alertasControllers) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final unidade = _categoria.unidade;

    return Scaffold(
      appBar: AppBar(
        title: Text(_editando ? 'Editar equipamento' : 'Novo equipamento'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Center(child: _buildSeletorFoto()),
            const SizedBox(height: 20),

            DropdownButtonFormField<CategoriaEquipamento>(
              value: _categoria,
              decoration: const InputDecoration(labelText: 'Categoria'),
              items: CategoriaEquipamento.values
                  .map((c) => DropdownMenuItem(value: c, child: Text(c.label)))
                  .toList(),
              onChanged: _aoTrocarCategoria,
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _nomeController,
              decoration: const InputDecoration(labelText: 'Nome do equipamento'),
              textCapitalization: TextCapitalization.words,
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Informe o nome' : null,
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _patrimonioController,
              decoration: const InputDecoration(labelText: 'Número de patrimônio / identificação'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Informe o patrimônio' : null,
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _valorAtualController,
              decoration: InputDecoration(
                labelText: '${_categoria.rotuloControle} atual ($unidade)',
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: _validarNumero,
            ),
            const SizedBox(height: 14),

            TextFormField(
              controller: _intervaloController,
              decoration: InputDecoration(
                labelText: 'Intervalo de manutenção ($unidade)',
                helperText: _editando
                    ? 'Usado para calcular a próxima meta ao concluir uma manutenção'
                    : 'Define a meta da próxima manutenção: valor atual + intervalo',
                helperMaxLines: 2,
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: _validarNumero,
            ),
            const SizedBox(height: 20),

            Text(
              'Alertas (unidade restante para notificar)',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              'Do menos urgente para o mais urgente. Ex.: gerador 100h, 50h, 20h, 10h.',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12.5),
            ),
            const SizedBox(height: 10),
            _buildListaAlertas(unidade),

            const SizedBox(height: 14),
            TextFormField(
              controller: _observacoesController,
              decoration: const InputDecoration(labelText: 'Observações'),
              maxLines: 3,
            ),
            const SizedBox(height: 28),

            ElevatedButton.icon(
              onPressed: _salvando ? null : _salvar,
              icon: _salvando
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.save),
              label: Text(_editando ? 'Salvar alterações' : 'Cadastrar equipamento'),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  String? _validarNumero(String? v) {
    if (v == null || v.trim().isEmpty) return 'Informe um valor';
    final parsed = double.tryParse(v.replaceAll(',', '.'));
    if (parsed == null) return 'Valor inválido';
    return null;
  }

  Widget _buildSeletorFoto() {
    return GestureDetector(
      onTap: _escolherFoto,
      child: Container(
        width: 120,
        height: 120,
        decoration: BoxDecoration(
          color: AppTheme.corPrimaria.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.corPrimaria.withOpacity(0.3)),
        ),
        child: _fotoPath != null && File(_fotoPath!).existsSync()
            ? ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(File(_fotoPath!), fit: BoxFit.cover),
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_a_photo, size: 34, color: AppTheme.corPrimaria),
                  const SizedBox(height: 6),
                  Text('Foto', style: TextStyle(color: AppTheme.corPrimaria)),
                ],
              ),
      ),
    );
  }

  Widget _buildListaAlertas(String unidade) {
    return Column(
      children: [
        for (int i = 0; i < _alertasControllers.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _alertasControllers[i],
                    decoration: InputDecoration(labelText: 'Alerta ${i + 1} ($unidade)'),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    validator: _validarNumero,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.remove_circle_outline),
                  onPressed: _alertasControllers.length <= 1
                      ? null
                      : () => setState(() => _alertasControllers.removeAt(i).dispose()),
                ),
              ],
            ),
          ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => setState(() => _alertasControllers.add(TextEditingController())),
            icon: const Icon(Icons.add),
            label: const Text('Adicionar nível de alerta'),
          ),
        ),
      ],
    );
  }
}
