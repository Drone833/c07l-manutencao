import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/equipamento.dart';
import '../providers/equipamento_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/stat_card.dart';
import 'equipamentos_list_screen.dart';
import 'equipamento_form_screen.dart';
import 'qr_scan_screen.dart';
import 'settings_screen.dart';

/// Tela inicial do app: mostra os contadores gerais (em dia, atenção,
/// próximos, vencidos) e dá acesso rápido às principais ações.
class DashboardScreen extends StatefulWidget {
  final ValueChanged<ThemeMode> onAlterarTema;
  final ThemeMode temaAtual;

  const DashboardScreen({
    super.key,
    required this.onAlterarTema,
    required this.temaAtual,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final provider = context.read<EquipamentoProvider>();
      await provider.carregarEquipamentos();
      // Verifica alertas ao abrir o app — funciona mesmo offline.
      await provider.verificarTodosOsAlertas();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EquipamentoProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Equipe C07-L — Drone'),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner),
            tooltip: 'Escanear QR Code',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const QrScanScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Configurações',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SettingsScreen(
                  onAlterarTema: widget.onAlterarTema,
                  temaAtual: widget.temaAtual,
                ),
              ),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => provider.carregarEquipamentos(),
        child: provider.carregando
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text(
                    'Situação da frota',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.3,
                    children: [
                      StatCard(
                        titulo: 'Em dia',
                        valor: provider.totalEmDia,
                        cor: AppTheme.statusVerde,
                        icone: Icons.check_circle,
                        onTap: () => _abrirListaFiltrada(context, StatusManutencao.verde),
                      ),
                      StatCard(
                        titulo: 'Atenção',
                        valor: provider.totalAtencao,
                        cor: AppTheme.statusAmarelo,
                        icone: Icons.info,
                        onTap: () => _abrirListaFiltrada(context, StatusManutencao.amarelo),
                      ),
                      StatCard(
                        titulo: 'Próximos da manutenção',
                        valor: provider.totalProximos,
                        cor: AppTheme.statusLaranja,
                        icone: Icons.warning_amber,
                        onTap: () => _abrirListaFiltrada(context, StatusManutencao.laranja),
                      ),
                      StatCard(
                        titulo: 'Vencidos',
                        valor: provider.totalVencidos,
                        cor: AppTheme.statusVermelho,
                        icone: Icons.error,
                        onTap: () => _abrirListaFiltrada(context, StatusManutencao.vermelho),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Ações rápidas',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  _botaoAcaoGrande(
                    context,
                    icone: Icons.list_alt,
                    texto: 'Ver todos os equipamentos',
                    cor: AppTheme.corPrimaria,
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const EquipamentosListScreen()),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _botaoAcaoGrande(
                    context,
                    icone: Icons.add_circle,
                    texto: 'Cadastrar novo equipamento',
                    cor: AppTheme.corSecundaria,
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const EquipamentoFormScreen()),
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _botaoAcaoGrande(
    BuildContext context, {
    required IconData icone,
    required String texto,
    required Color cor,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      height: AppTheme.alturaBotaoGrande,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: cor,
          foregroundColor: Colors.white,
        ),
        onPressed: onPressed,
        icon: Icon(icone, size: AppTheme.tamanhoIconeGrande),
        label: Text(texto, style: const TextStyle(fontSize: 16)),
      ),
    );
  }

  void _abrirListaFiltrada(BuildContext context, StatusManutencao status) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EquipamentosListScreen(filtroStatusInicial: status),
      ),
    );
  }
}
