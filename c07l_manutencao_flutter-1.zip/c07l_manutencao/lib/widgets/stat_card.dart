import 'package:flutter/material.dart';

/// Cartão grande usado no dashboard para mostrar contadores
/// (equipamentos em dia, próximos da manutenção, vencidos...).
/// Toque grande e texto legível — pensado para uso em campo.
class StatCard extends StatelessWidget {
  final String titulo;
  final int valor;
  final Color cor;
  final IconData icone;
  final VoidCallback? onTap;

  const StatCard({
    super.key,
    required this.titulo,
    required this.valor,
    required this.cor,
    required this.icone,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: cor.withOpacity(0.12),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: cor.withOpacity(0.4)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icone, color: cor, size: 30),
              const SizedBox(height: 8),
              Text(
                '$valor',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: cor,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                titulo,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: cor.withOpacity(0.9),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
