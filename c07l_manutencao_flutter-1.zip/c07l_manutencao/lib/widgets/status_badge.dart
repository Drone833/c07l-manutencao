import 'package:flutter/material.dart';
import '../models/equipamento.dart';
import '../theme/app_theme.dart';

/// Selo colorido que indica visualmente a situação do equipamento
/// (verde / amarelo / laranja / vermelho), conforme especificado.
class StatusBadge extends StatelessWidget {
  final StatusManutencao status;
  final bool compacto;

  const StatusBadge({super.key, required this.status, this.compacto = false});

  @override
  Widget build(BuildContext context) {
    final cor = AppTheme.corDoStatus(status);

    if (compacto) {
      return Container(
        width: 14,
        height: 14,
        decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: cor.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cor, width: 1.2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 10,
            height: 10,
            margin: const EdgeInsets.only(right: 6),
            decoration: BoxDecoration(color: cor, shape: BoxShape.circle),
          ),
          Text(
            status.label,
            style: TextStyle(
              color: cor,
              fontWeight: FontWeight.w600,
              fontSize: 12.5,
            ),
          ),
        ],
      ),
    );
  }
}
