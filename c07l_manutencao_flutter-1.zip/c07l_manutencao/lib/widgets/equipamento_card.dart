import 'dart:io';
import 'package:flutter/material.dart';

import '../models/equipamento.dart';
import '../theme/app_theme.dart';
import 'status_badge.dart';

/// Card usado na lista de equipamentos. Mostra foto, nome, patrimônio,
/// valor atual/restante e o selo de status colorido.
class EquipamentoCard extends StatelessWidget {
  final Equipamento equipamento;
  final VoidCallback onTap;

  const EquipamentoCard({super.key, required this.equipamento, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final status = equipamento.status;
    final cor = AppTheme.corDoStatus(status);
    final unidade = equipamento.categoria.unidade;

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              _buildFoto(),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      equipamento.nome,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${equipamento.categoria.label} • Pat. ${equipamento.patrimonio}',
                      style: TextStyle(fontSize: 12.5, color: Colors.grey.shade600),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.speed, size: 16, color: cor),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            equipamento.restante >= 0
                                ? 'Faltam ${equipamento.restante.toStringAsFixed(1)} $unidade'
                                : 'Vencida há ${equipamento.restante.abs().toStringAsFixed(1)} $unidade',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: cor,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    StatusBadge(status: status),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFoto() {
    const tamanho = 64.0;
    if (equipamento.fotoPath != null && File(equipamento.fotoPath!).existsSync()) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.file(
          File(equipamento.fotoPath!),
          width: tamanho,
          height: tamanho,
          fit: BoxFit.cover,
        ),
      );
    }
    return Container(
      width: tamanho,
      height: tamanho,
      decoration: BoxDecoration(
        color: AppTheme.corPrimaria.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        AppTheme.iconeDaCategoria(equipamento.categoria),
        color: AppTheme.corPrimaria,
        size: 30,
      ),
    );
  }
}
