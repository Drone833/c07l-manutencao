import 'dart:io';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/equipamento.dart';
import '../models/manutencao.dart';

/// Serviço responsável por gerar relatórios em PDF:
/// 1) relatório geral da frota (todos os equipamentos e situação)
/// 2) relatório individual com histórico de manutenções de um equipamento
class PdfService {
  PdfService._();

  static final DateFormat _formatoData = DateFormat('dd/MM/yyyy');

  /// Gera o PDF com a situação geral de todos os equipamentos.
  static Future<File> gerarRelatorioGeral(List<Equipamento> equipamentos) async {
    final doc = pw.Document();

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (context) => _cabecalho('Relatório Geral de Equipamentos'),
        footer: (context) => _rodape(context),
        build: (context) => [
          pw.SizedBox(height: 12),
          pw.Table.fromTextArray(
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
            cellStyle: const pw.TextStyle(fontSize: 9),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.blueGrey100),
            cellAlignment: pw.Alignment.centerLeft,
            columnWidths: {
              0: const pw.FlexColumnWidth(2.2),
              1: const pw.FlexColumnWidth(1.4),
              2: const pw.FlexColumnWidth(1.4),
              3: const pw.FlexColumnWidth(1.3),
              4: const pw.FlexColumnWidth(1.3),
              5: const pw.FlexColumnWidth(1.6),
            },
            headers: [
              'Equipamento',
              'Categoria',
              'Patrimônio',
              'Valor atual',
              'Restante',
              'Situação',
            ],
            data: equipamentos.map((e) {
              final unidade = e.categoria.unidade;
              return [
                e.nome,
                e.categoria.label,
                e.patrimonio,
                '${e.valorAtual.toStringAsFixed(1)} $unidade',
                '${e.restante.toStringAsFixed(1)} $unidade',
                e.status.label,
              ];
            }).toList(),
          ),
          pw.SizedBox(height: 16),
          pw.Text(
            'Total de equipamentos: ${equipamentos.length}',
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
          ),
        ],
      ),
    );

    return _salvarPdf(doc, 'relatorio_geral_${_timestamp()}.pdf');
  }

  /// Gera o PDF individual de um equipamento com seu histórico de manutenções.
  static Future<File> gerarRelatorioEquipamento(
    Equipamento equipamento,
    List<Manutencao> historico,
  ) async {
    final doc = pw.Document();
    final unidade = equipamento.categoria.unidade;

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        header: (context) => _cabecalho('Ficha do Equipamento'),
        footer: (context) => _rodape(context),
        build: (context) => [
          pw.SizedBox(height: 12),
          pw.Text(equipamento.nome,
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 4),
          pw.Text('Categoria: ${equipamento.categoria.label}'),
          pw.Text('Patrimônio: ${equipamento.patrimonio}'),
          pw.Text(
              '${equipamento.categoria.rotuloControle} atual: ${equipamento.valorAtual.toStringAsFixed(1)} $unidade'),
          pw.Text(
              'Próxima manutenção prevista para: ${equipamento.proximaManutencao.toStringAsFixed(1)} $unidade'),
          pw.Text('Situação atual: ${equipamento.status.label}'),
          pw.Text(
              'Última atualização: ${_formatoData.format(equipamento.ultimaAtualizacao)}'),
          if (equipamento.observacoes.isNotEmpty) ...[
            pw.SizedBox(height: 6),
            pw.Text('Observações: ${equipamento.observacoes}'),
          ],
          pw.SizedBox(height: 20),
          pw.Text('Histórico de Manutenções',
              style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          if (historico.isEmpty)
            pw.Text('Nenhuma manutenção registrada até o momento.')
          else
            pw.Table.fromTextArray(
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
              cellStyle: const pw.TextStyle(fontSize: 9),
              headerDecoration: const pw.BoxDecoration(color: PdfColors.blueGrey100),
              columnWidths: {
                0: const pw.FlexColumnWidth(1.2),
                1: const pw.FlexColumnWidth(1.2),
                2: const pw.FlexColumnWidth(2),
                3: const pw.FlexColumnWidth(1),
                4: const pw.FlexColumnWidth(2.2),
              },
              headers: ['Data', 'Valor', 'Peças trocadas', 'Custo', 'Observações'],
              data: historico.map((m) {
                return [
                  _formatoData.format(m.data),
                  '${m.valorNoMomento.toStringAsFixed(1)} $unidade',
                  m.pecasTrocadas.isEmpty ? '-' : m.pecasTrocadas,
                  'R\$ ${m.custo.toStringAsFixed(2)}',
                  m.observacoes.isEmpty ? '-' : m.observacoes,
                ];
              }).toList(),
            ),
        ],
      ),
    );

    return _salvarPdf(
      doc,
      'ficha_${equipamento.patrimonio}_${_timestamp()}.pdf',
    );
  }

  static pw.Widget _cabecalho(String titulo) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('Equipe C07-L (Drone) — Manutenção Preventiva',
            style: pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
        pw.Text(titulo, style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text('Gerado em: ${_formatoData.format(DateTime.now())}',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        pw.Divider(),
      ],
    );
  }

  static pw.Widget _rodape(pw.Context context) {
    return pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 8),
      child: pw.Text(
        'Página ${context.pageNumber} de ${context.pagesCount}',
        style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey600),
      ),
    );
  }

  static Future<File> _salvarPdf(pw.Document doc, String nomeArquivo) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/$nomeArquivo');
    await file.writeAsBytes(await doc.save());
    return file;
  }

  static String _timestamp() => DateTime.now().millisecondsSinceEpoch.toString();

  /// Abre a caixa de diálogo do sistema para visualizar/imprimir/compartilhar
  /// o PDF gerado.
  static Future<void> compartilharPdf(File arquivo) async {
    await Printing.sharePdf(bytes: await arquivo.readAsBytes(), filename: arquivo.path.split('/').last);
  }
}
