import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../models/equipamento.dart';
import '../theme/app_theme.dart';

/// Serviço responsável por disparar notificações locais (push local),
/// que funcionam mesmo sem conexão com a internet — não dependem de
/// nenhum servidor remoto (FCM), apenas do sistema operacional.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  bool _inicializado = false;

  Future<void> inicializar() async {
    if (_inicializado) return;

    tz_data.initializeTimeZones();

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const initSettings = InitializationSettings(
      android: androidInit,
      iOS: iosInit,
    );

    await _plugin.initialize(initSettings);

    // Cria o canal de notificação no Android (necessário a partir do Android 8).
    const canal = AndroidNotificationChannel(
      'c07l_manutencao_canal',
      'Alertas de Manutenção C07-L',
      description: 'Avisos de manutenção preventiva dos equipamentos',
      importance: Importance.high,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(canal);

    // Solicita permissão de notificação (Android 13+ / iOS).
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    await _plugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(alert: true, badge: true, sound: true);

    _inicializado = true;
  }

  /// Dispara imediatamente uma notificação local para um equipamento
  /// que atingiu um novo nível de alerta.
  Future<void> notificarAlerta(Equipamento equipamento) async {
    await inicializar();

    final status = equipamento.status;
    final unidade = equipamento.categoria.unidade;
    final restante = equipamento.restante;

    final titulo = status == StatusManutencao.vermelho
        ? '🔴 Manutenção vencida: ${equipamento.nome}'
        : '⚠️ Manutenção se aproximando: ${equipamento.nome}';

    final corpo = status == StatusManutencao.vermelho
        ? 'A manutenção de ${equipamento.categoria.rotuloControle.toLowerCase()} '
            'está vencida há ${restante.abs().toStringAsFixed(1)} $unidade. '
            'Patrimônio: ${equipamento.patrimonio}.'
        : 'Faltam apenas ${restante.toStringAsFixed(1)} $unidade para a '
            'próxima manutenção. Patrimônio: ${equipamento.patrimonio}.';

    final androidDetails = AndroidNotificationDetails(
      'c07l_manutencao_canal',
      'Alertas de Manutenção C07-L',
      channelDescription: 'Avisos de manutenção preventiva dos equipamentos',
      importance: Importance.high,
      priority: Priority.high,
      color: AppTheme.corDoStatus(status),
      styleInformation: BigTextStyleInformation(corpo),
    );

    final details = NotificationDetails(
      android: androidDetails,
      iOS: const DarwinNotificationDetails(),
    );

    // Usa o id do equipamento como id da notificação para permitir
    // atualizar/substituir a notificação anterior do mesmo equipamento.
    await _plugin.show(
      equipamento.id ?? equipamento.hashCode,
      titulo,
      corpo,
      details,
    );
  }

  /// Cancela qualquer notificação pendente de um equipamento
  /// (por exemplo, quando a manutenção é registrada e resolvida).
  Future<void> cancelarAlerta(Equipamento equipamento) async {
    await _plugin.cancel(equipamento.id ?? equipamento.hashCode);
  }

  /// Agenda uma verificação diária (notificação silenciosa de sistema
  /// não é necessária aqui — a verificação real dos limiares acontece
  /// em AlertaChecker, chamado ao abrir o app e ao salvar equipamentos).
  Future<void> cancelarTodas() async {
    await _plugin.cancelAll();
  }
}
