import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../database/database_helper.dart';
import '../models/equipamento.dart';
import '../models/manutencao.dart';

/// Serviço de exportação e importação de todos os dados do app
/// (equipamentos + histórico de manutenções) em um único arquivo JSON.
///
/// Uso típico:
/// - Exportar antes de trocar de aparelho ou como backup de segurança.
/// - Importar em outro dispositivo da equipe para restaurar o cadastro.
///
/// Este formato de arquivo também é a base para uma futura sincronização
/// na nuvem opcional (o mesmo JSON pode ser enviado para um servidor).
class ExportImportService {
  ExportImportService._();

  static const String versaoFormato = '1.0';

  /// Gera o arquivo JSON de backup com todos os dados e retorna o File.
  static Future<File> exportarDados() async {
    final db = DatabaseHelper.instance;
    final equipamentos = await db.listarEquipamentos();
    final manutencoes = await db.listarTodasManutencoes();

    final conteudo = {
      'versaoFormato': versaoFormato,
      'geradoEm': DateTime.now().toIso8601String(),
      'equipe': 'C07-L (Drone)',
      'equipamentos': equipamentos.map((e) => e.toJson()).toList(),
      'manutencoes': manutencoes.map((m) => m.toJson()).toList(),
    };

    final dir = await getApplicationDocumentsDirectory();
    final nomeArquivo =
        'backup_c07l_${DateTime.now().millisecondsSinceEpoch}.json';
    final file = File('${dir.path}/$nomeArquivo');
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(conteudo),
    );
    return file;
  }

  /// Exporta e imediatamente abre a caixa de compartilhamento do sistema
  /// (permite salvar em Drive, enviar por e-mail/WhatsApp, etc.).
  static Future<void> exportarECompartilhar() async {
    final file = await exportarDados();
    await Share.shareXFiles([XFile(file.path)],
        text: 'Backup de dados — Manutenção C07-L');
  }

  /// Deixa o usuário escolher um arquivo .json de backup e restaura os
  /// dados no banco local. [substituirTudo] apaga os dados atuais antes
  /// de importar; caso contrário, os registros são adicionados.
  static Future<int> importarDados({bool substituirTudo = false}) async {
    final resultado = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
    );
    if (resultado == null || resultado.files.single.path == null) {
      return 0; // usuário cancelou
    }

    final file = File(resultado.files.single.path!);
    final conteudo = jsonDecode(await file.readAsString()) as Map<String, dynamic>;

    final db = DatabaseHelper.instance;
    if (substituirTudo) {
      await db.limparTudo();
    }

    final listaEquipamentos = (conteudo['equipamentos'] as List? ?? []);
    final listaManutencoes = (conteudo['manutencoes'] as List? ?? []);

    // Mapeia o id antigo do equipamento -> novo id inserido, para manter
    // a relação correta entre manutenções e equipamentos importados.
    final Map<int, int> mapaIds = {};

    for (final item in listaEquipamentos) {
      final original = Equipamento.fromJson(item as Map<String, dynamic>);
      final semId = original.copyWith();
      final novoId = await db.inserirEquipamento(
        Equipamento(
          nome: semId.nome,
          categoria: semId.categoria,
          patrimonio: semId.patrimonio,
          valorAtual: semId.valorAtual,
          proximaManutencao: semId.proximaManutencao,
          intervaloManutencao: semId.intervaloManutencao,
          ultimaAtualizacao: semId.ultimaAtualizacao,
          fotoPath: semId.fotoPath,
          observacoes: semId.observacoes,
          alertasConfigurados: semId.alertasConfigurados,
        ),
      );
      if (original.id != null) mapaIds[original.id!] = novoId;
    }

    int importados = listaEquipamentos.length;

    for (final item in listaManutencoes) {
      final original = Manutencao.fromJson(item as Map<String, dynamic>);
      final novoEquipamentoId = mapaIds[original.equipamentoId];
      if (novoEquipamentoId == null) continue; // equipamento não encontrado
      await db.inserirManutencao(
        Manutencao(
          equipamentoId: novoEquipamentoId,
          data: original.data,
          valorNoMomento: original.valorNoMomento,
          pecasTrocadas: original.pecasTrocadas,
          custo: original.custo,
          observacoes: original.observacoes,
          fotos: original.fotos,
        ),
      );
      importados++;
    }

    return importados;
  }
}
