import 'package:flutter/foundation.dart';

import '../database/database_helper.dart';
import '../models/equipamento.dart';
import '../models/manutencao.dart';
import '../services/notification_service.dart';

/// Provider central do app: mantém a lista de equipamentos em memória,
/// fala com o banco (DatabaseHelper) e dispara notificações quando o
/// nível de alerta de um equipamento muda.
class EquipamentoProvider extends ChangeNotifier {
  final DatabaseHelper _db = DatabaseHelper.instance;

  List<Equipamento> _equipamentos = [];
  bool carregando = false;

  List<Equipamento> get equipamentos => _equipamentos;

  // --------------------------- Dashboard ---------------------------

  int get totalEmDia =>
      _equipamentos.where((e) => e.status == StatusManutencao.verde).length;

  int get totalAtencao =>
      _equipamentos.where((e) => e.status == StatusManutencao.amarelo).length;

  int get totalProximos =>
      _equipamentos.where((e) => e.status == StatusManutencao.laranja).length;

  int get totalVencidos => _equipamentos
      .where((e) => e.status == StatusManutencao.vermelho)
      .length;

  // --------------------------- Carregamento ---------------------------

  Future<void> carregarEquipamentos({
    String? termoBusca,
    CategoriaEquipamento? categoria,
  }) async {
    carregando = true;
    notifyListeners();

    _equipamentos = await _db.listarEquipamentos(
      termoBusca: termoBusca,
      categoria: categoria,
    );

    carregando = false;
    notifyListeners();
  }

  // --------------------------- CRUD Equipamento ---------------------------

  Future<Equipamento> salvarEquipamento(Equipamento equipamento) async {
    Equipamento salvo;
    if (equipamento.id == null) {
      final id = await _db.inserirEquipamento(equipamento);
      salvo = equipamento.copyWith(id: id);
    } else {
      await _db.atualizarEquipamento(equipamento);
      salvo = equipamento;
    }

    await _verificarEDispararAlerta(salvo);
    await carregarEquipamentos();
    return salvo;
  }

  Future<void> excluirEquipamento(int id) async {
    await _db.excluirEquipamento(id);
    await carregarEquipamentos();
  }

  Future<Equipamento?> buscarPorId(int id) => _db.buscarEquipamentoPorId(id);

  /// Atualiza apenas o valor de controle (horímetro/km/horas de voo),
  /// recalcula status e dispara alerta se necessário. Usado no "check-in
  /// rápido" de campo, sem precisar abrir o formulário completo.
  Future<void> atualizarValorAtual(Equipamento equipamento, double novoValor) async {
    final atualizado = equipamento.copyWith(
      valorAtual: novoValor,
      ultimaAtualizacao: DateTime.now(),
    );
    await _db.atualizarEquipamento(atualizado);
    await _verificarEDispararAlerta(atualizado);
    await carregarEquipamentos();
  }

  /// Registra que uma manutenção foi feita: soma o intervalo configurado
  /// ao valor atual para definir a nova meta de "próxima manutenção",
  /// zera o alerta e cancela notificações pendentes daquele equipamento.
  Future<void> registrarManutencaoConcluida(
    Equipamento equipamento,
    Manutencao manutencao,
  ) async {
    await _db.inserirManutencao(manutencao);

    final atualizado = equipamento.copyWith(
      valorAtual: manutencao.valorNoMomento,
      proximaManutencao: manutencao.valorNoMomento + equipamento.intervaloManutencao,
      ultimaAtualizacao: manutencao.data,
      ultimoNivelAlertaNotificado: -1,
    );
    await _db.atualizarEquipamento(atualizado);
    await NotificationService.instance.cancelarAlerta(atualizado);
    await carregarEquipamentos();
  }

  // --------------------------- Histórico de manutenções ---------------------------

  Future<List<Manutencao>> historicoDoEquipamento(int equipamentoId) =>
      _db.listarManutencoesPorEquipamento(equipamentoId);

  Future<void> excluirManutencao(int id) => _db.excluirManutencao(id);

  // --------------------------- Alertas / Notificações ---------------------------

  /// Compara o nível de alerta atual com o último nível já notificado.
  /// Só dispara uma nova notificação quando o equipamento *piora* de
  /// nível (evita notificações repetidas a cada pequena atualização).
  Future<void> _verificarEDispararAlerta(Equipamento equipamento) async {
    final nivelAtual = equipamento.nivelAlertaAtual;

    if (nivelAtual != -1 && nivelAtual != equipamento.ultimoNivelAlertaNotificado) {
      await NotificationService.instance.notificarAlerta(equipamento);
      final comNivelAtualizado =
          equipamento.copyWith(ultimoNivelAlertaNotificado: nivelAtual);
      await _db.atualizarEquipamento(comNivelAtualizado);
    } else if (nivelAtual == -1 && equipamento.ultimoNivelAlertaNotificado != -1) {
      // Voltou a ficar em dia (ex.: manutenção intervalo recalculado).
      await NotificationService.instance.cancelarAlerta(equipamento);
      final resetado = equipamento.copyWith(ultimoNivelAlertaNotificado: -1);
      await _db.atualizarEquipamento(resetado);
    }
  }

  /// Roda uma varredura em todos os equipamentos e reemite notificações
  /// para os que estiverem em laranja/vermelho. Chamado ao abrir o app,
  /// garantindo que os alertas apareçam mesmo sem internet e mesmo que
  /// o valor não tenha sido atualizado manualmente.
  Future<void> verificarTodosOsAlertas() async {
    final todos = await _db.listarEquipamentos();
    for (final equipamento in todos) {
      await _verificarEDispararAlerta(equipamento);
    }
  }
}
