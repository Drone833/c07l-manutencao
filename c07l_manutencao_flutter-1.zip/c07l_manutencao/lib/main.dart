import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'providers/equipamento_provider.dart';
import 'screens/dashboard_screen.dart';
import 'services/notification_service.dart';
import 'theme/app_theme.dart';

/// Chave global usada para ler/gravar a preferência de tema (claro/escuro).
const String chavePrefTema = 'tema_modo'; // 'claro' | 'escuro' | 'sistema'

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Inicializa notificações locais (não depende de internet).
  await NotificationService.instance.inicializar();

  runApp(const C07LApp());
}

class C07LApp extends StatefulWidget {
  const C07LApp({super.key});

  @override
  State<C07LApp> createState() => _C07LAppState();
}

class _C07LAppState extends State<C07LApp> {
  ThemeMode _themeMode = ThemeMode.system;

  @override
  void initState() {
    super.initState();
    _carregarTemaSalvo();
  }

  Future<void> _carregarTemaSalvo() async {
    final prefs = await SharedPreferences.getInstance();
    final valor = prefs.getString(chavePrefTema) ?? 'sistema';
    setState(() {
      _themeMode = switch (valor) {
        'claro' => ThemeMode.light,
        'escuro' => ThemeMode.dark,
        _ => ThemeMode.system,
      };
    });
  }

  /// Chamado pela tela de configurações para trocar e persistir o tema.
  Future<void> alterarTema(ThemeMode modo) async {
    final prefs = await SharedPreferences.getInstance();
    final valor = switch (modo) {
      ThemeMode.light => 'claro',
      ThemeMode.dark => 'escuro',
      ThemeMode.system => 'sistema',
    };
    await prefs.setString(chavePrefTema, valor);
    setState(() => _themeMode = modo);
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => EquipamentoProvider(),
      child: Builder(
        builder: (context) {
          return MaterialApp(
            title: 'Manutenção C07-L',
            debugShowCheckedModeBanner: false,
            theme: AppTheme.temaClaro,
            darkTheme: AppTheme.temaEscuro,
            themeMode: _themeMode,
            home: DashboardScreen(
              onAlterarTema: alterarTema,
              temaAtual: _themeMode,
            ),
          );
        },
      ),
    );
  }
}
