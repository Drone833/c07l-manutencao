# Manutenção C07-L (Drone)

Aplicativo Android de manutenção preventiva para controle de equipamentos
da equipe C07-L. Funciona 100% offline (banco de dados SQLite local) com
exportação/importação de dados prontos para uma futura sincronização em
nuvem.

## O que já vem pronto neste pacote

```
lib/
  main.dart                          # ponto de entrada do app
  models/
    equipamento.dart                 # modelo + cálculo de status/cores
    manutencao.dart                  # modelo de histórico de manutenção
  database/
    database_helper.dart             # SQLite (CRUD completo)
  providers/
    equipamento_provider.dart        # estado global + regra de alertas
  services/
    notification_service.dart        # notificações locais (sem internet)
    pdf_service.dart                 # relatórios em PDF
    export_import_service.dart       # backup/restauração em JSON
  theme/
    app_theme.dart                   # tema claro/escuro + cores de status
  screens/
    dashboard_screen.dart
    equipamentos_list_screen.dart
    equipamento_form_screen.dart
    equipamento_detail_screen.dart
    manutencao_form_screen.dart
    qr_scan_screen.dart
    settings_screen.dart
  widgets/
    status_badge.dart
    stat_card.dart
    equipamento_card.dart
pubspec.yaml                          # todas as dependências já configuradas
```

Este pacote **não inclui as pastas `android/` e `ios/`** porque elas são
geradas automaticamente pelo próprio Flutter (contêm arquivos específicos
da versão do SDK instalada na sua máquina). É rápido gerar — veja o passo
a passo abaixo.

## Passo a passo para compilar no Android Studio

### 1. Pré-requisitos
- Flutter SDK instalado (`flutter --version` para conferir)
- Android Studio com o plugin Flutter/Dart instalado
- Um emulador ou celular Android em modo desenvolvedor (depuração USB)

### 2. Criar o esqueleto do projeto
Extraia este pacote em uma pasta, por exemplo `c07l_manutencao/`, depois
rode no terminal, **dentro dessa pasta**:

```bash
flutter create --org com.suaequipe --project-name c07l_manutencao .
```

Esse comando gera as pastas `android/`, `ios/`, `web/`, etc., sem
sobrescrever o `lib/` e o `pubspec.yaml` que já vêm prontos (responda "y"
se ele perguntar sobre sobrescrever `.gitignore`/`analysis_options.yaml`).

### 3. Instalar as dependências

```bash
flutter pub get
```

### 4. Ajustar permissões do Android
Abra `android/app/src/main/AndroidManifest.xml` e adicione, **dentro da
tag `<manifest>`, antes de `<application>`**:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

E dentro da tag `<application>`, garanta que exista (o `mobile_scanner`
exige a feature de câmera, mas sem torná-la obrigatória para instalar em
tablets sem câmera traseira):

```xml
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

### 5. Definir o `minSdkVersion`
Em `android/app/build.gradle` (ou `build.gradle.kts`), garanta:

```
minSdk = 21
```

(exigido pelos pacotes `mobile_scanner` e `flutter_local_notifications`).

### 6. Rodar / compilar

```bash
flutter run
```

Ou, para gerar o APK de instalação:

```bash
flutter build apk --release
```

O APK final fica em `build/app/outputs/flutter-apk/app-release.apk`.

Abrir no Android Studio: `File > Open`, selecione a pasta do projeto, e
use o botão "Run" normalmente após seguir os passos acima.

## Como o app resolve cada requisito pedido

- **Cadastro por categoria** (`lib/models/equipamento.dart`): cada
  categoria (Gerador, Caminhonete, Caminhão MUC, Drone) já define a
  unidade de controle (horímetro/km/horas de voo) e valores padrão de
  intervalo e alerta, mas tudo é reconfigurável equipamento a equipamento
  na tela de cadastro.

- **Cores de status** (`Equipamento.status` em `equipamento.dart`):
  algoritmo único que funciona para qualquer categoria, comparando o
  valor restante até a manutenção com os limiares de alerta configurados.
  Verde / Amarelo / Laranja / Vermelho são calculados automaticamente.

- **Alertas configuráveis por valor restante**: cada equipamento guarda
  uma lista de limiares (`alertasConfigurados`), editável na tela de
  formulário. Os valores sugeridos por categoria já seguem exatamente o
  que foi pedido (gerador 100/50/20/10h, drone 10/5/2/1h, caminhonete e
  MUC 1000/500/100 km + vencida).

- **Notificações locais mesmo sem internet**
  (`services/notification_service.dart`): usa `flutter_local_notifications`,
  que dispara notificações pelo próprio sistema operacional, sem depender
  de servidor. São disparadas automaticamente quando o equipamento muda
  de faixa de alerta (ao salvar/atualizar valores) e também há uma
  varredura de todos os equipamentos toda vez que o app é aberto
  (`verificarTodosOsAlertas`), garantindo que o time veja o alerta mesmo
  que o app fique dias fechado.

- **Dashboard**: contadores de equipamentos em dia / atenção / próximos /
  vencidos, com toque em cada cartão abrindo a lista já filtrada.

- **Lista com busca e filtros**: busca por nome/patrimônio direto no
  SQLite + filtro por categoria (chips) + filtro por status.

- **Histórico de manutenções**: tela de detalhes lista todas as
  manutenções (data, valor no momento, peças, custo, observações, fotos),
  com opção de excluir um registro.

- **QR Code automático e leitura**: cada equipamento tem um QR Code
  gerado com `qr_flutter` (visível na tela de detalhes) contendo um
  identificador único. A tela de escaneamento (`qr_scan_screen.dart`) usa
  `mobile_scanner` para ler a câmera e abre diretamente o cadastro
  correspondente.

- **Exportar/Importar dados**: gera e lê um arquivo `.json` com todos os
  equipamentos e o histórico de manutenções — útil como backup e como
  base pronta para uma futura sincronização em nuvem (o mesmo formato
  poderia ser enviado a um servidor próprio da equipe).

- **Relatórios em PDF**: relatório geral da frota (tabela de todos os
  equipamentos e situação) e ficha individual por equipamento com o
  histórico completo, usando os pacotes `pdf` + `printing` (o segundo
  já abre a caixa de compartilhar/imprimir do Android).

- **Tema claro/escuro**: `Material 3`, com preferência salva localmente
  (`shared_preferences`) e opção de seguir o tema do sistema.

- **Uso em campo**: botões grandes (altura mínima de 56 px, ver
  `AppTheme.alturaBotaoGrande`), ícones grandes, cartões de toque amplo no
  dashboard, e formulários simplificados com poucos campos obrigatórios
  por tela.

## Sincronização em nuvem (opcional)

O app foi estruturado para que a sincronização seja um passo futuro e
opcional, sem quebrar o uso 100% offline:

- Todo o app já funciona sem nenhuma configuração de nuvem.
- O arquivo gerado em "Exportar dados" (JSON com `equipamentos` e
  `manutencoes`) é o formato que uma futura function/API da equipe
  poderia receber para consolidar os dados de vários celulares.
- Para implementar de fato, bastaria adicionar, em
  `export_import_service.dart`, uma chamada HTTP (`http` ou `dio`) que
  envie esse mesmo JSON para um endpoint próprio quando houver conexão
  (`connectivity_plus`, já incluso no `pubspec.yaml`, ajuda a detectar
  isso).

## Observações finais

- O ícone do app usa o ícone padrão gerado pelo `flutter create`; para
  personalizar, adicione o pacote `flutter_launcher_icons` e configure
  conforme a documentação oficial.
- Fotos de equipamentos e de manutenções ficam salvas na pasta de
  documentos do próprio app (`path_provider`), preservando-as mesmo que
  o arquivo original seja apagado da galeria.
- Todo o código está comentado em português, explicando o porquê de cada
  decisão importante (cálculo de status, notificações, etc.).
